<form action="<?= url('kelas/simpan'); ?>" method="POST">
    <?php include('form.php'); ?>
</form>