<form action="<?= url('kelas/update'); ?>" method="POST">
    <?php include('form.php'); ?>
</form>