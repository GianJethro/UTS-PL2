<form action="<?= url('spp/update'); ?>" method="POST">
    <?php include('form.php'); ?>
</form>