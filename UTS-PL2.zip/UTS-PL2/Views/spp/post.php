<form action="<?= url('spp/store'); ?>" method="POST">
    <?php include('form.php'); ?>
</form>