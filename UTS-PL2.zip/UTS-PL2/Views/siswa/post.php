<form action="<?= url('siswa/simpan'); ?>" method="POST">
    <?php include('form.php'); ?>
</form>