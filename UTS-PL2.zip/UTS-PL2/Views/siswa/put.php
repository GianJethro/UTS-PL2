<form action="<?= url('siswa/update'); ?>" method="POST">
    <?php include('form.php'); ?>
</form>