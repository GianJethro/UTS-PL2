<form action="<?= url('pembayaran/store'); ?>" method="POST">
    <?php include('form.php'); ?>
</form>