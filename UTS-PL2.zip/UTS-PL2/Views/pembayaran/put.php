<form action="<?= url('pembayaran/update'); ?>" method="POST">
    <?php include('form.php'); ?>
</form>