<form action="<?= url('petugas/simpan'); ?>" method="POST">
    <?php include('form.php'); ?>
</form>