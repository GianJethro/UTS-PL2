<form action="<?= url('petugas/update'); ?>" method="POST">
    <?php include('form.php'); ?>
</form>